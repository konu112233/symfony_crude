<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* pages/index.html.twig */
class __TwigTemplate_f295ca7c7efd816327a266af52f92c5a2f23926f2c03f72be6aa8946ac1aa99f extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "pages/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "pages/index.html.twig"));

        // line 1
        echo twig_include($this->env, $context, "pages/header.html.twig");
        echo "

<h1> View Posts</h1>
<div>
     <a href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("")), "html", null, true);
        echo "/app_dev.php/create\" class=\"btn btn-danger\">Create Posts</a></td>
  
  </div>

<table class=\"table table-hover\">
  <thead>
    <tr>
      <th scope=\"col\">ID</th>
      <th scope=\"col\">Title</th>
      <th scope=\"col\">Description</th>
      <th scope=\"col\">Category</th>
      <th scope=\"col\">Action</th>
    </tr>
  </thead>
  <tbody>
  ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["posts"] ?? $this->getContext($context, "posts")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["mydata"]) {
            // line 21
            echo "    <tr class=\"table-active\">
      <th scope=\"row\">";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["mydata"], "id", []), "html", null, true);
            echo "</th>
      <td>";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["mydata"], "title", []), "html", null, true);
            echo "</td>
      <td>";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["mydata"], "description", []), "html", null, true);
            echo "</td>
      <td>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["mydata"], "category", []), "html", null, true);
            echo "</td>
      <td><a href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("")), "html", null, true);
            echo "app_dev.php/view/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["mydata"], "id", []), "html", null, true);
            echo "\" class=\"btn btn-primary\">View</a>
      <a href=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("")), "html", null, true);
            echo "app_dev.php/edit/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["mydata"], "id", []), "html", null, true);
            echo "\" class=\"btn btn-success\">Edit</a>
      <a href=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("")), "html", null, true);
            echo "app_dev.php/delete/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["mydata"], "id", []), "html", null, true);
            echo "\" class=\"btn btn-danger\">Delete</a></td>
    </tr>
    
    ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 32
            echo "    <tr>
    <td no records found </td>
    </tr>
    
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['mydata'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "    
  </tbody>
</table> 

";
        // line 41
        echo twig_include($this->env, $context, "pages/footer.html.twig");
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "pages/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 41,  118 => 37,  108 => 32,  97 => 28,  91 => 27,  85 => 26,  81 => 25,  77 => 24,  73 => 23,  69 => 22,  66 => 21,  61 => 20,  43 => 5,  36 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{{ include('pages/header.html.twig') }}

<h1> View Posts</h1>
<div>
     <a href=\"{{ absolute_url(asset('')) }}/app_dev.php/create\" class=\"btn btn-danger\">Create Posts</a></td>
  
  </div>

<table class=\"table table-hover\">
  <thead>
    <tr>
      <th scope=\"col\">ID</th>
      <th scope=\"col\">Title</th>
      <th scope=\"col\">Description</th>
      <th scope=\"col\">Category</th>
      <th scope=\"col\">Action</th>
    </tr>
  </thead>
  <tbody>
  {% for mydata in posts %}
    <tr class=\"table-active\">
      <th scope=\"row\">{{ mydata.id }}</th>
      <td>{{ mydata.title }}</td>
      <td>{{ mydata.description }}</td>
      <td>{{ mydata.category }}</td>
      <td><a href=\"{{ absolute_url(asset('')) }}app_dev.php/view/{{ mydata.id }}\" class=\"btn btn-primary\">View</a>
      <a href=\"{{ absolute_url(asset('')) }}app_dev.php/edit/{{ mydata.id }}\" class=\"btn btn-success\">Edit</a>
      <a href=\"{{ absolute_url(asset('')) }}app_dev.php/delete/{{ mydata.id }}\" class=\"btn btn-danger\">Delete</a></td>
    </tr>
    
    {% else %}
    <tr>
    <td no records found </td>
    </tr>
    
  {% endfor %}
    
  </tbody>
</table> 

{{ include('pages/footer.html.twig') }}", "pages/index.html.twig", "C:\\xampp\\htdocs\\projectv1\\app\\Resources\\views\\pages\\index.html.twig");
    }
}
