<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* pages/view.html.twig */
class __TwigTemplate_bca0484ffb2d397802aa80c904fe2777ca1a4e8519b8b03e1fc156e0a1bffd71 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "pages/view.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "pages/view.html.twig"));

        // line 1
        echo twig_include($this->env, $context, "pages/header.html.twig");
        echo "

<div>
<a href=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("")), "html", null, true);
        echo "app_dev.php/post\" class=\"btn btn-primary\">Back</a>

</div>

<div>
<h1> View Post </h1>
</div>
<form>
  <fieldset>
    <legend>Legend</legend>
    <div class=\"form-group row\">
      <label for=\"staticEmail\" class=\"col-sm-2 col-form-label\">Title</label>
      <div class=\"col-sm-10\">
        <input type=\"text\" readonly=\"\" class=\"form-control-plaintext\" id=\"staticEmail\" value=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute(($context["posts"] ?? $this->getContext($context, "posts")), "title", []), "html", null, true);
        echo "\">
      </div>
    </div>
    
    
     <div class=\"form-group row\">
      <label for=\"staticEmail\" class=\"col-sm-2 col-form-label\">Description</label>
      <div class=\"col-sm-10\">
        <input type=\"text\" readonly=\"\" class=\"form-control-plaintext\" id=\"staticEmail\" value=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute(($context["posts"] ?? $this->getContext($context, "posts")), "description", []), "html", null, true);
        echo "\">
      </div>
    </div>
    
     <div class=\"form-group row\">
      <label for=\"staticEmail\" class=\"col-sm-2 col-form-label\">Category</label>
      <div class=\"col-sm-10\">
        <input type=\"text\" readonly=\"\" class=\"form-control-plaintext\" id=\"staticEmail\" value=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute(($context["posts"] ?? $this->getContext($context, "posts")), "category", []), "html", null, true);
        echo "\">
      </div>
    </div>
    
    <button type=\"submit\" class=\"btn btn-primary\">Submit</button>
  </fieldset>
</form>


";
        // line 41
        echo twig_include($this->env, $context, "pages/footer.html.twig");
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "pages/view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 41,  79 => 32,  69 => 25,  58 => 17,  42 => 4,  36 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{{ include('pages/header.html.twig') }}

<div>
<a href=\"{{ absolute_url(asset('')) }}app_dev.php/post\" class=\"btn btn-primary\">Back</a>

</div>

<div>
<h1> View Post </h1>
</div>
<form>
  <fieldset>
    <legend>Legend</legend>
    <div class=\"form-group row\">
      <label for=\"staticEmail\" class=\"col-sm-2 col-form-label\">Title</label>
      <div class=\"col-sm-10\">
        <input type=\"text\" readonly=\"\" class=\"form-control-plaintext\" id=\"staticEmail\" value=\"{{ posts.title }}\">
      </div>
    </div>
    
    
     <div class=\"form-group row\">
      <label for=\"staticEmail\" class=\"col-sm-2 col-form-label\">Description</label>
      <div class=\"col-sm-10\">
        <input type=\"text\" readonly=\"\" class=\"form-control-plaintext\" id=\"staticEmail\" value=\"{{ posts.description }}\">
      </div>
    </div>
    
     <div class=\"form-group row\">
      <label for=\"staticEmail\" class=\"col-sm-2 col-form-label\">Category</label>
      <div class=\"col-sm-10\">
        <input type=\"text\" readonly=\"\" class=\"form-control-plaintext\" id=\"staticEmail\" value=\"{{ posts.category }}\">
      </div>
    </div>
    
    <button type=\"submit\" class=\"btn btn-primary\">Submit</button>
  </fieldset>
</form>


{{ include('pages/footer.html.twig') }}", "pages/view.html.twig", "C:\\xampp\\htdocs\\projectv1\\app\\Resources\\views\\pages\\view.html.twig");
    }
}
